"""

       Mini-task 1 - f-strings and slicing

       Task: Display the following output given the string below:
            OS: Windows NT 10.0

"""
ua = 'Mozilla/5.0 (Windows NT 10.0)'
left = ua.find('(')
right = ua.find(')')
# put your solution here
print(f'OS: {ua[left]}')